input_filename = input('Enter input filename:')
output_filename = input('Enter output filename:')
