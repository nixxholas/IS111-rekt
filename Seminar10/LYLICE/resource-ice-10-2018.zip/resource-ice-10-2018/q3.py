def check_spelling(sentence, dictionary):
	# added pass to make this script executable
	pass
	
def get_english_dictionary(filename):
	pass

