filename = input('Enter filename>')
num_spaces_per_tab = int(input('Enter num of spaces for a tab>'))

