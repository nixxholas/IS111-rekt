### Q1b Reading Files
# Write your code below:





