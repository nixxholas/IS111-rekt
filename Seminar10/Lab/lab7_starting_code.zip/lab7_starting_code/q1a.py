## Q1 Reading Files
# Write your code below:
##############################






