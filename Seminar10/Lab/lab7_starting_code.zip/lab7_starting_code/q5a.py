### Q5a: Matrix

# Write your code below:



