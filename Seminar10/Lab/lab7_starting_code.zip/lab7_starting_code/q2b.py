### Q2b: Universities 
# Write your code below:



