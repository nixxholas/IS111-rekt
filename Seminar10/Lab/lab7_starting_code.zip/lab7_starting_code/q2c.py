### Q2c: Universities 
# Write your code below:



