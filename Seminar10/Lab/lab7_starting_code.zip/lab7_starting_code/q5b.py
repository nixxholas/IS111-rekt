### Q5b: Matrix

# Write your code below:



