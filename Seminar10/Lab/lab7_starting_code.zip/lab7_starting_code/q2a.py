### Q2a: Universities 
# Write your code below:



