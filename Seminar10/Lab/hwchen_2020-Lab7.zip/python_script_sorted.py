1. def my_test_func(param1, param2):
    This is a test function that takes in two parameters and returns a number.
    The two parameters are compared. 0 or 1 is returned.

2. def another_function():
	This is a function without any parameter.

3. def third_funct():
	This is a function
    that has two lines of docstring.

