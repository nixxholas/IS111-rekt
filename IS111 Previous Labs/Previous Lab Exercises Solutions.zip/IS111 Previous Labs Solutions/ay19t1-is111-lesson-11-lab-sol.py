def count_words(filename):
    count = 0
    with open(filename, 'r') as f:
        for line in f:
            line_list = line.lower().split()
            count += len(line_list)
    return count 

# r = count_words('lab-11-shakespeare.txt')
# print(r)

def print_file(filename, n, m):
    line_num = 1
    with open(filename, 'r') as f:
        for line in f:
            if line_num % n == 0:
                print(line.strip())
            if line_num >= m:
                return 
            line_num += 1
    return 

# print_file('lab-11-shakespeare.txt', 3, 10)

def qn21(filename):
    types = []
    fibreyear = None
    belowyear = None 
    currentinfo = {}
    with open(filename, 'r') as f:
        f.readline()
        for line in f:
            line_list = line.strip().split(',')
            if line_list[1] not in types:
                types.append(line_list[1])
            if line_list[1] == 'fibre broadband' and line_list[2].isnumeric() and fibreyear is None:
                fibreyear = int(line_list[0])
            if line_list[0] not in currentinfo: 
                currentinfo[line_list[0]] = {line_list[1]:line_list[2]}
            else: 
                currentinfo[line_list[0]][line_list[1]] = line_list[2]
            if 'fixed broadband' in currentinfo[line_list[0]] and 'wireless broadband' in currentinfo[line_list[0]]:
                if currentinfo[line_list[0]]['fixed broadband'] < currentinfo[line_list[0]]['wireless broadband'] and belowyear is None:
                    belowyear = line_list[0]

    print(types)
    print('fibreyear', fibreyear)
    print('belowyear', belowyear)
    return             

# qn21('lab-11-internet.csv')

def qn22(filename, output_filename): 
    output = {}
    with open(filename, 'r') as f:
        f.readline()
        for line in f:
            list_ = line.strip().split(',')
            year = int(list_[0].split('-')[0])
            if year in output:
                output[year] += float(list_[1])
            else: 
                output[year] = float(list_[1])

    # sort first
    output_list = list(output.items())
    output_list.sort()

    with open(output_filename, 'w') as f:
        f.write('year,volume_of_mobile_data'+"\n")
        for output in output_list:
            s = str(output[0])+','+str(round(output[1],5))+"\n"
            f.write(s)
    return 

# qn22('lab-11-mobile.csv', 'lab-11-mobile-output.csv')

def qn31(filename, output_filename):
    output = {}
    with open(filename, 'r') as f:
        f.readline()
        for line in f: 
            list_ = line.strip().split(',')
            year = list_[0]
            if year in output: 
                output[year][list_[3]] += int(list_[4])
            else: 
                output[year] = {'MF':0, 'F':0}
                output[year][list_[3]] += int(list_[4])

    # sort first
    output_list = list(output.items())
    output_list.sort()
    print(output_list)

    with open(output_filename, 'w') as f:
        f.write('year,num_male_students'+"\n")
        for output in output_list:
            males = output[1]['MF'] - output[1]['F']
            s = str(output[0])+','+str(males)+"\n"
            f.write(s)
    return 

qn31('lab-11-secondary.csv', 'lab-11-secondary-output.csv')