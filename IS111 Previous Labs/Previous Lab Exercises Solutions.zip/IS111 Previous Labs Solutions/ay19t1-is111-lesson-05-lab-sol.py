def get_intersection(list1, list2):
    x = []
    for i in list1:
        if i in list2 and i not in x:
            x.append(i)
    return x 

print(get_intersection([1,2,'a','#',2], [2,3,3,'#']) == ([2,'#'] or ['#',2]))
print(get_intersection([1,2,3],[4,5,'d']) == [])

def compute_manhattan_distance(list1, list2):
    if len(list1) != len(list2):
        return 
    ans = 0
    for i in range(len(list1)):
        ans += abs(list1[i] - list2[i])
    return ans

# print(compute_manhattan_distance([1,4,10,5], [5,2,8,5]) == 8)
# print(compute_manhattan_distance([1,4,10,5,12,52], [5,2,8,5,18]) == None)

def generate_2d(a, b):
    list_ = []
    for i in range(1,b+1):
        list_.append(i)
    list_final = []
    for i in range(a):
        list_final.append(list_)
    return list_final

# print(generate_2d(3,4) == [[1,2,3,4],[1,2,3,4],[1,2,3,4]])
# print(generate_2d(2,5) == [[1,2,3,4,5],[1,2,3,4,5]])

def sum_of_neighbors(input_list):
    x = [] 
    for i in range(len(input_list)):
        x.append(input_list[i]) 
        if i-1 in range(len(input_list)):
            x[i] += input_list[i-1]
        if i+1 in range(len(input_list)):
            x[i] += input_list[i+1]
    return x

# print(sum_of_neighbors([10,20,30,40,50]) == [30,60,90,120,90])
# print(sum_of_neighbors([23]) == [23])
# print(sum_of_neighbors([56,-10,25,-32]) == [46,71,-17,-7])