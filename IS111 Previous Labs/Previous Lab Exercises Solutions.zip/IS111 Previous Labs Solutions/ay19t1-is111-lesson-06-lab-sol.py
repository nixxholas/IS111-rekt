def get_cheapest_fruit(price_list):
    cheapest = None 
    for i in price_list:
        if cheapest is None or i[1] < cheapest[1]:
            cheapest = i 
    return cheapest[0]
    
print(get_cheapest_fruit([('banana',1.95), ('rockmelon',8.50), ('watermelon',6.25), ('melon',4.50), ('peach',5.90), ('limes',1.10)]) == 'limes')
print(get_cheapest_fruit([('lemons',4.05), ('apples',4.00), ('oranges',3.75)]) == 'oranges')

def compute_shopping_cart(shopping_list):
    total = 0
    for i in shopping_list:
        total += i[1]*i[2]
    return round(total,2)

print(compute_shopping_cart([('banana',1.95,1), ('rockmelon',8.50,3), ('watermelon',6.25,2), ('melon',4.50,1), ('peach',5.90,0), ('limes',1.10,6)]) == 51.05)
print(compute_shopping_cart([('lemons',4.05,4), ('apples',4.00,2), ('oranges',3.75,3)]) == 35.45)

def get_rewards(total_points, points_required):
    max_rewards = total_points // points_required
    remainder = total_points % points_required
    return (max_rewards, remainder)

print(get_rewards(4300,1100) == (3,1000))
print(get_rewards(20540,360) == (57,20))
print(get_rewards(2300,3000) == (0,2300))

def tic_tac_toe_checker(marked_play):
    winning_seq = [(0,1,2), (3,4,5), (6,7,8), (0,3,6), (1,4,7), (2,5,8), (0,4,8), (2,4,6)]
    for i in winning_seq:
        if marked_play[i[0]] == marked_play[i[1]] and marked_play[i[0]] == marked_play[i[2]] and marked_play[i[0]] != '-':
            return marked_play[i[0]]
    return 'D'

print(tic_tac_toe_checker(['X', 'X', 'O', '-', 'X', 'O', '-', 'O', 'O']) == 'O')
print(tic_tac_toe_checker(['X', 'X', 'O', 'O', 'X', 'O', '-', 'O', 'X']) == 'X')
print(tic_tac_toe_checker(['X', 'X', 'O', 'O', 'O', 'X', 'X', 'X', 'O']) == 'D')

