# Lab 1 Solution
#Q1.1 Body Mass Index (BMI) Calculator 
height = float(input("Please type your height in cm: "))
weight = float(input("Please type your weight in kg: "))

height_meters = height/100

BMI = weight / height_meters**2

print("Your BMI is {:.2f}" .format(BMI))

#Q1.2 Area of Sphere  
import math

radius_sphere = float(input("Please type in radius of the sphere: "))
area_sphere = 4 * math.pi * (radius_sphere**2)

print("Area of sphere (2dp) is {:.2f}" .format(area_sphere))
print("Area of sphere (3dp) is {:.3f}" .format(area_sphere))

# Question: why is my output different from the sample output?
# Is the numerical value of math.pi different?

#Q2.1  Max of 3 Random Numbers
import random

num_1 = random.randint(1, 10)
num_2 = random.randint(1, 10)
num_3 = random.randint(1, 10)

print(f"The four random numbers generated are: {num_1}, {num_2} and {num_3}")

print(f"The highest number is: {max(num_1, num_2, num_3)}.")

#Q3.1 Odd/Even Numbers 
import random

num_1 = random.randint(1, 10)
num_2 = random.randint(1, 10)
num_3 = random.randint(1, 10)
num_4 = random.randint(1, 10)
percentage_odd = 0 #Set to 0 to reset for multiple runs 

print(f"The four random numbers generated are: {num_1}, {num_2}, {num_3} and {num_4}")

percentage_odd += ((num_1%2 + num_2%2 + num_3%2 + num_4%2) / 4) *100

print(f"The percentage of odd numbers is: {int(percentage_odd)}%")
print(f"The percentage of odd numbers is: {(100 - int(percentage_odd))}%")
