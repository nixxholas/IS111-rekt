import string

def mask_mobile(mobile_number):
	x = '****' + str(mobile_number)[4:]
	return x

# print(mask_mobile(87654321) == '****4321')
# print(mask_mobile(91234567) == '****4567')

def mask_email(email_address):
	index = email_address.find('@')
	masked_email = '*'*index + email_address[index:]
	return masked_email

# print(mask_email('abcdef@gmail.com') == '******@gmail.com')
# print(mask_email('is111@gmail.com') == '*****@gmail.com')

def get_num_solutions(a, b, c):
	x = b**2 - 4*a*c
	if x == 0:
		return 1
	elif x < 0 :
		return 0
	return 2 

# print(get_num_solutions(4,5,6) == 0)
# print(get_num_solutions(3,6,3) == 1)
# print(get_num_solutions(2,4,1) == 2)

def calculate_rows_of_lights(budget, cost_per_light):
	max_lights = budget // cost_per_light
	# n = (a+l)/2, or use loops for practice 
	num_rows = 0
	num_used = 0 
	for i in range(1, max_lights+1):
		num_used += i
		if num_used <= max_lights:
			num_rows += 1
		else:
			break 
	return num_rows

# print(calculate_rows_of_lights(50,2) == 6) 
# print(calculate_rows_of_lights(100,3) == 7) 
# print(calculate_rows_of_lights(10,12) == 0)

def pass_ippt(pushup_score, situp_score, run_score):
	if pushup_score + situp_score + run_score < 51:
		return False 
	if pushup_score == 0 or situp_score == 0 or run_score == 0:
		return False
	return True 

# print(pass_ippt(10,20,20) == False)
# print(pass_ippt(20,0,40) == False)
# print(pass_ippt(20,15,33) == True)

def encode_caesar(plaintext, key):
	ciphertext = ''
	for i in range(len(plaintext)):
		if plaintext[i] in string.ascii_lowercase:
			ciphertext += string.ascii_lowercase[(string.ascii_lowercase.find(plaintext[i])+key)%26]
		elif plaintext[i] in string.ascii_uppercase:
			ciphertext += string.ascii_uppercase[(string.ascii_uppercase.find(plaintext[i])+key)%26]
		else: 
			ciphertext += plaintext[i]
	return ciphertext

# print(encode_caesar("If you want something badly enough, do not give up!", -3) == "Fc vlr txkq pljbqefkd yxaiv bklrde, al klq dfsb rm!")
# print(encode_caesar("Programming is SO FUN!", 12) == "Bdasdmyyuzs ue EA RGZ!")
