# Q1.1
import random
def random_generator(a,b,c):
    total=0
    while total<c:
        rand=random.randint(a,b)
        total+=rand
        print(f"adding {rand}, total is {total}")
    return

random_generator(3,10,15)

# Q1.2
def multiplication_table(n):
    i = 1
    while i < 11:
        print(f'{i} x {n} = {i*n}')
        i+= 1

multiplication_table(7)

# Q1.3
def binary_to_decimal(s):
    i = 0
    decimal = 0
    while i < len(s):
        decimal += int(s[i])*2**(len(s) - (i+1))
        i+=1
    return decimal

print(binary_to_decimal('1011')) # returns 11
print(binary_to_decimal('01001100')) # returns 76

# Q2.1
def decimal_to_binary(d):
    binary=""
    quotient=d
    while quotient!=0 or len(binary)==0 or (len(binary)%4!=0):
        binary+=str(quotient%2)
        quotient=quotient//2
    return binary[::-1]
print(decimal_to_binary(11)) # returns '1011'
print(decimal_to_binary(76)) # returns '1001100'

# Q2.2 Snake and Ladder
from random import randint
def snakes_and_ladders(snakeladder_list):
    print('Welcome to Snake and Ladder board game. Your board number is 0.')
    counter = 0
    user_input = ''
    while counter < 20: 
        user_input = input("Enter 'r' to roll the dice, or type 'No' to quit: ")

        if user_input == 'No':
            print('Thank you for playing.')
            break
        elif user_input == 'r':
            dice = randint(1,6)
            counter += dice
            for snakeladder in snakeladder_list:
                if counter == snakeladder[0]:
                    counter += snakeladder[1]
                    print(f'The dice number is {dice} and you land on a space with {snakeladder}. Your new board number is {counter}.')
                    break
            else: 
                print(f'The dice number is {dice}. Your new board number is {counter}.')
        else:
            continue
    else:
        print('You win the game!')

snakes_and_ladders([(6,-3), (10,5), (13,-2),(14,5), (18,-6)])

# Q3.1
def compute_sine(x, n):
    i = 1
    sign = 1
    sine = 0
    while i <= n:
        numerator = x**i
        denom = 1 
        j = 1 
        while j <= i:
            denom *= j 
            j += 1
        curr_term = numerator/denom  
        curr_term = curr_term*sign 
        sine += curr_term
        sign *= -1 
        i += 2
    return round(sine,5) 

print(compute_sine(5, 29)) # returns -0.95892
print(compute_sine(0.5, 21)) # returns 0.47943
print(compute_sine(-0.2, 19)) # returns -0.1987
    
