def compute_checksum(partial_nric):
    weight_dict = {1:2, 2:7, 3:6, 4:5, 5:4, 6:3, 7:2}
    lookup_st = {10:'A', 9:'B', 8:'C', 7:'D', 6:'E', 5:'F', 4:'G', 3:'H', 2:'I', 1:'Z', 0:'J'}
    lookup_fg = {10:'K', 9:'L', 8:'M', 7:'N', 6:'P', 5:'Q', 4:'R', 3:'T', 2:'U', 1:'W', 0:'X'}
    weighted_sum = 0 
    for i in range(1, len(partial_nric)):
        weighted_sum += int(partial_nric[i])*weight_dict[i]
    if partial_nric[0] == 'T' or partial_nric[0] == 'G':
        weighted_sum += 4
    mod = weighted_sum % 11
    if partial_nric[0] == 'S' or partial_nric[0] == 'T':
        checksum = lookup_st[mod]
    else: 
        checksum = lookup_fg[mod]
    return checksum

r1 = compute_checksum('S1234567') # returns 'D'
r2 = compute_checksum('G1234567') # returns 'X'
r3 = compute_checksum('T7654321') # returns 'B'
r4 = compute_checksum('F7654321') # returns 'Q'
#print(r1,r2,r3,r4)    

import math

def get_nearest_driver(passenger_loc, driver_loc):
    dist_dict = {}
    for k, v in driver_loc.items():
        lat1 = math.radians(passenger_loc[0])
        lon1 = math.radians(passenger_loc[1])
        lat2 = math.radians(v[0])
        lon2 = math.radians(v[1])
        d = 6371 * math.acos(math.sin(lat1) * math.sin(lat2) + math.cos(lat1) * math.cos(lat2) * math.cos(lon1-lon2))
        dist_dict[k] = round(d,2)
    
    print(dist_dict)

get_nearest_driver((1.297490, 103.849600), {'A':(1.318350,103.843100),'B':(1.290210,103.859512)})