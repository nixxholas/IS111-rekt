import string 

def count_words(s):
    count = 1 
    for i in s:
        if i in string.ascii_uppercase:
            count += 1 
    return count 

# print(count_words('alphabets'))
# print(count_words('camelCasing'))
# print(count_words('eatPrayLove'))

import math 

def count_perfect_sq(a,b):
    count = 0
    start = math.floor(a**0.5)
    while True: 
        if a <= start**2 <= b:
            count += 1
        if start**2 > b: 
            break
        start += 1
    return count 

# r1 = count_perfect_sq(1,3)
# r2 = count_perfect_sq(4,30)
# r3 = count_perfect_sq(37,47)
# print(r1,r2,r3)

def robot_dest(s): 
    x = 0
    y = 0
    for i in s:
        if i == 'L':
            y -= 1
        elif i == 'R':
            y += 1
        elif i == 'U':
            x += 1
        elif i == 'D':
            x -= 1
    return (x,y)

r1 = robot_dest('UULRDRDDDD')
r2 = robot_dest('URLD')
print(r1,r2)

def compute_diagonal_diff(matrix_list):
    r = 0
    l = 0
    for i in range(len(matrix_list)):
        r += matrix_list[i][i]
    for i in range(len(matrix_list)):
        l += matrix_list[i][len(matrix_list)-1-i]
    return abs(r-l)

# res = compute_diagonal_diff([[1,2,3], [4,5,6], [8,8,9]])
# print(res)
# res = compute_diagonal_diff([[11,2,4,4], [10,4,-4,3], [1,1,5,5],[3,3,-8,4]])
# print(res)


def check_magic_square(matrix_list):
    sum_ = -1  
    for row in matrix_list:
        curr_sum = sum(row) 
        if sum_ == -1:
            sum_ = curr_sum
        elif sum_ != curr_sum:
            return False   
    for i in range(len(matrix_list)):
        curr_sum = 0 
        for j in range(len(matrix_list)):
            curr_sum += matrix_list[j][i]
        if sum_ != curr_sum:
            return False 
    r, l = 0, 0 
    for i in range(len(matrix_list)):
        r += matrix_list[i][i]
    for i in range(len(matrix_list)):
        l += matrix_list[i][len(matrix_list)-1-i]
    if sum_ != r or sum_ != l:
        return False
    return True  

# r1 = check_magic_square([[2,7,6], [9,5,1], [4,3,8]]) # returns True
# r2 = check_magic_square([[1,2,3], [4,5,6], [7,8,9]]) # returns False
# r3 = check_magic_square([[16,3,2,13], [5,10,11,8], [9,6,7,12], [4,15,14,1]]) # returns True 
# print(r1, r2, r3)

def play_music(playlist, commute_duration): 
    total = 0 
    num_songs = 0 
    while total < commute_duration: 
        if total + playlist[num_songs][1] <= commute_duration:
            total += playlist[num_songs][1]
            num_songs += 1
            if num_songs == len(playlist):
                break
        else:
            break 
    return num_songs

# r1 = play_music([('a',360),('b',300),('c',220),('d',400)],0)
# r2 = play_music([('a',360),('b',300),('c',220),('d',400)],40)
# r3 = play_music([('a',360),('b',300),('c',220),('d',400)],290)
# r4 = play_music([('a',360),('b',300),('c',220),('d',400)],660)
# r5 = play_music([('a',360),('b',300),('c',220),('d',400)],900)
# r6 = play_music([('a',360),('b',300),('c',220),('d',400)],2000)
# print(r1,r2,r3,r4,r5,r6)
