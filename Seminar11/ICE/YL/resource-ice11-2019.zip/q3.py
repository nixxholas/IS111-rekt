def get_common_misspelling_dict(filename):
    pass


def auto_correct_sentence(sentence, dictionary):
    pass
    