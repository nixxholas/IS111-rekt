## Q2 Prime Numbers
# write your code below