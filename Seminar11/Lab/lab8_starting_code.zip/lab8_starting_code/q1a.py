## Q1a Substitution Cipher
# write your code below

