## Q1b Substitution Cipher
# write your code below