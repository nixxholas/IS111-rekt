## Q5a Word Counts
# write your code below