## Q4 Students and Schools
# write your code below


