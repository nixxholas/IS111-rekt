import q3

print("Test Case for Q3")
print()

q3.process_numbers("numbers.txt", "output.txt")
print("Please check whether the file 'output.txt' generated is the same as the file 'expected-output.txt' that we've provided.")
