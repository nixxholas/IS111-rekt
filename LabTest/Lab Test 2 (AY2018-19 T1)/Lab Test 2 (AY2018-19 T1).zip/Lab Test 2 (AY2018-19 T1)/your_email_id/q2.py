#
# Name: 
# Email ID: 
#
def get_prices_in_range(price_list, low, high):
    # Modify the code below    
    return None