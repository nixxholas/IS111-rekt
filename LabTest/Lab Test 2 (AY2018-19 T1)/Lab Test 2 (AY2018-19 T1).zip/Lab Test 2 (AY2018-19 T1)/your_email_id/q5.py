#
# Name: 
# Email ID: 
#

# If needed, you can define your own additional functions here.
# Start of your additional functions.


# End of your additional functions.

def convert_to_list(num_list_str):
    # Modify the code below
    return []
    
