#
# Name: 
# Email ID: 
#

# If needed, you can define your own additional functions here.
# Start of your additional functions.


# End of your additional functions.

def find_stations_within_distance(mrt_map, orig, dist):
    # Modify the code below
    return []

