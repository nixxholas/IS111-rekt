# Name: Nicholas Chen Han Wei
# Email ID: hwchen.2020

def get_tank_volume(width, depth, height):
    return int((width * depth * height) / 1000)
