def evaluate(expression):
    # modify the code below
    return 0.0
