def scramble(word, file_name):
    # modify the code below
    return []
    