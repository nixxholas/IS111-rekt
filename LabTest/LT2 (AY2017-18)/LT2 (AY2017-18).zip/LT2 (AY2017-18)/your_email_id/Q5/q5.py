def get_family_members(head):
    # modify the code below
    return []
    
