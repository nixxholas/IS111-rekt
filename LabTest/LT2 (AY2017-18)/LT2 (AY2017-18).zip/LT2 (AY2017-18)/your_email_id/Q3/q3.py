def get_postal_codes(file_name):
    # modify the code below
    return []
